FPS Boost (Fabric, 1.21.11)
Build: install JDK 21, run `gradle wrapper` once (or use any Gradle 9+), then `./gradlew build`.
Jar: build/libs/fpsboost-1.0.0.jar -> put in .minecraft/mods with Fabric API.
Settings: .minecraft/config/fpsboost.json (created on first launch).
If a version in gradle.properties is not found, use the latest for 1.21.11 from fabricmc.net/develop.
