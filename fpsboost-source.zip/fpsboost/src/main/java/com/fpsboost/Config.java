package com.fpsboost;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Edit config/fpsboost.json in your .minecraft folder. Radii are in blocks, 0 = unlimited. */
public class Config {
    public int maxPerCell = 1;            // same-type armor stands/minecarts/items/etc per block cell
    public int maxLivingPerCell = 8;      // same-type mobs per block cell (stops mob-farm lag)
    public double armorStandRadius = 32;
    public double minecartRadius = 48;
    public double itemRadius = 32;
    public double tntRadius = 64;
    public double xpRadius = 24;
    public double frameRadius = 24;       // item frames, paintings
    public double projectileRadius = 48;  // arrows, tridents
    public double boatRadius = 64;
    public double livingRadius = 64;      // mobs (players are never culled)
    public double defaultRadius = 96;
    public boolean cullBlockEntities = true;
    public double chestRadius = 32;       // chests, trapped chests, ender chests, barrels
    public double shulkerRadius = 32;
    public double signRadius = 16;        // signs + hanging signs (text is expensive)
    public double bannerRadius = 32;
    public double bedRadius = 32;
    public double skullRadius = 32;
    public double spawnerRadius = 24;     // spawner cage + spinning mob
    public double portalRadius = 48;      // end portal / gateway / conduit
    public double otherBlockEntityRadius = 48; // everything else (lecterns, pots, bells, campfires...)
    // beacons are never culled so their beams keep working
    public boolean adaptive = true;       // shrink radii automatically when FPS is below targetFps
    public int targetFps = 60;
    public boolean limitParticles = true;
    public int maxParticlesPerTick = 400;
    public double particleRadius = 32;

    private static Config instance = new Config();
    public static Config get() { return instance; }

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("fpsboost.json");
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            if (Files.exists(file)) {
                Config c = gson.fromJson(Files.readString(file), Config.class);
                if (c != null) instance = c;
            }
            Files.writeString(file, gson.toJson(instance)); // writes defaults / fills new fields
        } catch (Exception ignored) { }
    }
}
