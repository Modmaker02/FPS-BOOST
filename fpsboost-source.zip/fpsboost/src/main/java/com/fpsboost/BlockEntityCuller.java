package com.fpsboost;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.IdentityHashMap;
import java.util.Map;

public final class BlockEntityCuller {
    private enum Kind { CHEST, SHULKER, SIGN, BANNER, BED, SKULL, SPAWNER, PORTAL, BEACON, OTHER }

    private static final Map<BlockEntityType<?>, Kind> kinds = new IdentityHashMap<>();

    // Registry names instead of class imports, so it survives refactors between versions.
    private static Kind kindOf(BlockEntity be) {
        return kinds.computeIfAbsent(be.getType(), t -> {
            String p = BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(t).getPath();
            if (p.contains("chest") || p.equals("barrel")) return Kind.CHEST;
            if (p.equals("shulker_box")) return Kind.SHULKER;
            if (p.contains("sign")) return Kind.SIGN;
            if (p.equals("banner")) return Kind.BANNER;
            if (p.equals("bed")) return Kind.BED;
            if (p.equals("skull")) return Kind.SKULL;
            if (p.equals("mob_spawner") || p.equals("trial_spawner") || p.equals("vault")) return Kind.SPAWNER;
            if (p.startsWith("end_") || p.equals("conduit")) return Kind.PORTAL;
            if (p.equals("beacon")) return Kind.BEACON;
            return Kind.OTHER;
        });
    }

    /** true = skip rendering this block entity */
    public static boolean shouldCull(BlockEntity be) {
        Config c = Config.get();
        if (!c.cullBlockEntities) return false;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;

        double r = switch (kindOf(be)) {
            case CHEST -> c.chestRadius;
            case SHULKER -> c.shulkerRadius;
            case SIGN -> c.signRadius;
            case BANNER -> c.bannerRadius;
            case BED -> c.bedRadius;
            case SKULL -> c.skullRadius;
            case SPAWNER -> c.spawnerRadius;
            case PORTAL -> c.portalRadius;
            case BEACON -> 0;
            case OTHER -> c.otherBlockEntityRadius;
        };
        r *= EntityCuller.scale();
        if (r <= 0) return false;

        BlockPos pos = be.getBlockPos();
        return mc.player.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > r * r;
    }
}
