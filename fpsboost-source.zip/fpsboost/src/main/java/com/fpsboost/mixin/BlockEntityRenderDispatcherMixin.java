package com.fpsboost.mixin;

import com.fpsboost.BlockEntityCuller;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockEntityRenderDispatcher.class)
public class BlockEntityRenderDispatcherMixin {
    // require = 0: if this method's signature differs in your exact version, the mod still loads
    // (entity + particle culling keep working) and only block-entity culling is skipped.
    @Inject(method = "tryExtractRenderState", at = @At("HEAD"), cancellable = true, require = 0)
    private void fpsboost$cull(BlockEntity blockEntity, float partialTick, @Coerce Object crumbling,
                               CallbackInfoReturnable<Object> cir) {
        if (BlockEntityCuller.shouldCull(blockEntity)) cir.setReturnValue(null);
    }
}
