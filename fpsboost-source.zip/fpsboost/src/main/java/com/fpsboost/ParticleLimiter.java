package com.fpsboost;

import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.phys.Vec3;

public final class ParticleLimiter {
    private static int added = 0;

    public static void newTick() { added = 0; }

    /** true = drop this particle */
    public static boolean shouldDrop(Particle p) {
        Config c = Config.get();
        if (!c.limitParticles) return false;
        double scale = EntityCuller.scale();
        if (++added > c.maxParticlesPerTick * scale) return true;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return false;
        Vec3 pos = p.getBoundingBox().getCenter();
        double r = c.particleRadius * scale;
        return r > 0 && mc.player.distanceToSqr(pos.x, pos.y, pos.z) > r * r;
    }
}
