package com.fpsboost;

import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.IdentityHashMap;
import java.util.Map;

public final class EntityCuller {
    private enum Kind { ARMOR_STAND, MINECART, ITEM, TNT, XP, FRAME, PROJECTILE, BOAT, LIVING, OTHER }

    private record Key(EntityType<?> type, int x, int y, int z) {}

    private static final Object2IntOpenHashMap<Key> counts = new Object2IntOpenHashMap<>();
    private static final Map<EntityType<?>, Kind> kinds = new IdentityHashMap<>();
    private static double scale = 1.0;

    public static void newTick(int fps) {
        counts.clear();
        Config c = Config.get();
        if (c.adaptive) {
            if (fps > 0 && fps < c.targetFps) scale = Math.max(0.4, scale * 0.97);
            else scale = Math.min(1.0, scale * 1.01);
        } else scale = 1.0;
    }

    public static double scale() { return scale; }

    // Uses registry names (not class imports) so it survives package moves between versions.
    private static Kind kindOf(Entity e) {
        return kinds.computeIfAbsent(e.getType(), t -> {
            String p = BuiltInRegistries.ENTITY_TYPE.getKey(t).getPath();
            if (p.equals("armor_stand")) return Kind.ARMOR_STAND;
            if (p.contains("minecart")) return Kind.MINECART;
            if (p.equals("item")) return Kind.ITEM;
            if (p.equals("tnt") || p.equals("falling_block")) return Kind.TNT;
            if (p.equals("experience_orb")) return Kind.XP;
            if (p.contains("item_frame") || p.equals("painting")) return Kind.FRAME;
            if (p.contains("arrow") || p.equals("trident")) return Kind.PROJECTILE;
            if (p.contains("boat") || p.contains("raft")) return Kind.BOAT;
            return Kind.OTHER;
        });
    }

    private static double radius(Kind k, Entity e, Config c) {
        return switch (k) {
            case ARMOR_STAND -> c.armorStandRadius;
            case MINECART -> c.minecartRadius;
            case ITEM -> c.itemRadius;
            case TNT -> c.tntRadius;
            case XP -> c.xpRadius;
            case FRAME -> c.frameRadius;
            case PROJECTILE -> c.projectileRadius;
            case BOAT -> c.boatRadius;
            default -> (e instanceof LivingEntity) ? c.livingRadius : c.defaultRadius;
        };
    }

    /** true = skip rendering this entity */
    public static boolean shouldCull(Entity e, double camX, double camY, double camZ) {
        if (e instanceof Player) return false;
        Config c = Config.get();
        Kind k = kindOf(e);

        double r = radius(k, e, c) * scale;
        if (r > 0) {
            double dx = e.getX() - camX, dy = e.getY() - camY, dz = e.getZ() - camZ;
            if (dx * dx + dy * dy + dz * dz > r * r) return true;
        }

        int limit;
        if (k == Kind.LIVING || (k == Kind.OTHER && e instanceof LivingEntity)) limit = c.maxLivingPerCell;
        else if (k == Kind.OTHER || k == Kind.FRAME || k == Kind.BOAT || k == Kind.PROJECTILE) return false;
        else limit = c.maxPerCell;
        if (limit <= 0) return false;

        Key key = new Key(e.getType(), (int) Math.floor(e.getX()), (int) Math.floor(e.getY()), (int) Math.floor(e.getZ()));
        return counts.addTo(key, 1) >= limit;
    }
}
